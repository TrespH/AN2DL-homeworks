# file: model.py
import numpy as np
from tensorflow.keras.models import load_model

class Model:
    def __init__(self):
        """Initializes the model's internal state."""
        # Load pre-trained model weights
        self.model = load_model('First_CNN_91.01.keras')

    def predict(self, X):
        """Returns a numpy array of labels for the given input X."""
        predictions = self.model.predict(X)
        predicted_labels = np.argmax(predictions, axis=1)
        return predicted_labels
